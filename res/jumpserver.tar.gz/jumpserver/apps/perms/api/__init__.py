# -*- coding: utf-8 -*-
#

from .asset_permission import *
from .user_permission import *
from .user_group_permission import *
from .remote_app_permission import *
from .user_remote_app_permission import *
